void game_rules(int[][4]);
void display(int arr[][4]);
void sort(int arr[][4]);
void loseGameSituation(void);
void gotoxy(int,int);
int winCon(int [][4]);


