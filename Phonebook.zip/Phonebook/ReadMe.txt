Hey Folks!

Using VS Code:-
1. I Have Built this Terminal application using Python as programming Language and Sql to support Database.
2. I Have created a seperate file to all the Util Functions and a main file from where they are directly or indirectly called.

Using Postgres SQL:-
1. I have created a table for all the users and a table of all the contacts.
2. Both tables have multiple distinguished data fields.
3. You'll have setup the database connection first in order to run this application in your device.
you have to create a user table, a contact table with same fields available in the program.

4. And All Set.

Enjoy!
