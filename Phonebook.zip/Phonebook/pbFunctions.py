import psycopg2
from termcolor import colored
try:
    conn=psycopg2.connect(
        host="localhost",
        database="phonebook",
        user="postgres",
        password="admin"
    )
    cur=conn.cursor()
except psycopg2.Error as e:
    print(colored('\nError While Connecting to Databse:','red',e))

def execute(sqL_query):
    try:
        cur.execute(sqL_query)
        conn.commit()
    except psycopg2.DatabaseError as e:
        conn.rollback()
        return e

def addContact(user_id):
    print(colored('\n----------Add Contact----------','magenta'))
    userData={
        'name':input(colored('Enter Your Name','yellow')),
        'contact':input(colored('Enter Contact Number','yellow')),
        'contact2':input(colored('Enter 2nd Contact Number','yellow')),
        'address':input(colored('Enter Address','yellow')),
        'email':input(colored('Enter E-Mail','yellow')),
        }

    sql_query=f"""
                insert into contacts (name,contact,contact2,address,email,userid) values (
                '{userData['name']}',
                '{userData['contact']}',
                '{userData['contact2']}',
                '{userData['address']}',
                '{userData['email']}',
                {user_id});"""
    
    print(execute(sql_query))
    choice=int(input(colored("\nPress 1 to Add Another Contact\nPress 2 to Go Back to Previosu Menu\nPress 3 to Exit",'green')))
    while True:
        if choice==1:
            addContact(user_id)
        elif choice==2:
            option(user_id)
        elif choice==3:
            exit()
        else:
            print(colored('\nInvalid Valid Choice','red'))
        
def updateContact(user_id):
    print(colored('\n----------Update Contact----------','blue'))
    choice=input(colored('\nWhat You want to update','yellow')).lower()
    person=input(colored("\nEnter Person's Name",'yellow'))
    if choice=='name':
        temp=input(colored('\nEnter New Name','yellow'))
        sql_query=f"UPDATE contacts SET name = '{temp}' where userid={user_id} AND name='{person}';"
        print(execute(sql_query))

    elif choice=='email':
        temp=input(colored('\nEnter New Email','yellow'))
        sql_query=f"UPDATE contacts SET email = '{temp}' where userid={user_id} AND name='{person}';"
        print(execute(sql_query))

    elif choice=='contact':
        temp=input(colored('\nEnter New Contact','yellow'))
        sql_query=f"UPDATE contacts SET contact='{temp}'where userid={user_id} AND name='{person}';"
        print(execute(sql_query))

    elif choice=='contact2':
        temp=input(colored("\nEnter New Contact 2",'yellow'))
        sql_query=f"UPDATE contacts SET contact2='{temp}' where userid={user_id} AND name='{person}';"
        print(execute(sql_query))

    elif choice=='address':
        temp=input(colored("\nEnter New Address",'yellow'))
        sql_query=f"UPDATE contacts SET address='{temp}' where userid={user_id} AND name='{person}';"
        print(execute(sql_query))

    elif choice=='e':
        exit()

    else:
        print(colored("\nWrong Choice",'red'))
    while True:
        choice2=int(input(colored('\nPress 1 to Update Contact\nPress 2 to Go Back to Main Menu\nPress 3 to Exit.','green')))
        if choice2==1:
            updateContact(user_id)
        elif choice2==2:
            option(user_id)
        elif choice2==3:
            exit()
        else:
            print(colored('\nInvalid Option','red'))

def deleteContact(user_id):
    print(colored('\n----------Delete Contact----------','blue'))
    name=input(colored('\nEnter Name of the Contact','yellow'))
    sql_query=f"delete from contacts where userid={user_id} AND name = '{name}';"
    if 'y'==input(colored('\nARE YOU SURE YOU WANT TO DELETE THIS CONTACT\nPRESS Y/N ','magenta')).lower():
        print(execute(sql_query))
    else:
        while True:
            choice=int(input(colored("\nPress 1 to Delete Contact\nPress 2 to Go Back To Main Menu\nPress 3 to Exit.",'green')))
            if choice==1:
                deleteContact(user_id)
            elif choice==2:
                option(user_id)
            elif choice==3:
                exit()
            else:
                print(colored('\nInvalid Option','red'))

def viewContact(user_id):
    print(colored('\n----------View Contact----------','blue'))
    name=input(colored("\nEnter Contact's Name",'yellow'))
    sql_query=f"select * from contacts where userid={user_id} AND name='{name}';"
    print(execute(sql_query))
    for row in cur.fetchall():
        print(row)
    while True:
        choice=int(input(colored('\nPress 1 to View Contact\nPress 2 to Go Back To Main Menu\nPress 3 to Exit','green')))
        if choice==1:
            viewContact(user_id)
        elif choice==2:
            option(user_id)
        elif choice==3:
            exit()
        else:
            print(colored('\nInvalid Option','red'))
    

def viewAllContacts(user_id):
    print(colored('\n----------View All Contacts----------','blue'))
    sql_query=f"select * from contacts where userid={user_id};"
    print(execute(sql_query))
    for row in cur.fetchall():
        print(row[0],row[1],row[2],row[3],row[4],row[5])
    while True:
        choice=int(input(colored('\nPress 1 to View All Contacts\nPress 2 to Go Back To Main Menu\nPress 3 to Exit','green')))
        if choice==1:
            viewAllContacts(user_id)
        elif choice==2:
            option(user_id)
        elif choice==3:
            exit()
        else:
            print(colored('\nInvalid Option','red'))

def option(user_id):
        print(colored('\n-------Options Page---------','blue'))
        print(colored('\n1.Add New Contact\n2.Edit Contact\n3.Delete Contact\n4.View Contacts\n5.View All Contacts\n6.Exit','green'))
        option=int(input(colored('\nEnter Your Choice:','yellow')))

        if option==1:
            addContact(user_id)
        elif option==2:
            updateContact(user_id)
        elif option==3:
            deleteContact(user_id)
        elif option==4:
            viewContact(user_id)
        elif option==5:
            viewAllContacts(user_id)
        elif option==6:
            exit()
        else:
            print(colored('\nEnter Valid Choice','red'))
            option(user_id)

def resetPassword():
    print(colored('\n--------Password Reset Page--------','blue'))
    userData={'email':input(colored('\nEnter Your Email','yellow')),'contact':input(colored('Enter Contact','yellow'))}
    sql_query=f"select * from users where email='{userData['email']}'"
    execute(sql_query)
    result=cur.fetchone()
    if result is not None:
        if result[4]==userData['contact']:
            new_password=input(colored('\nEnter New Password','yellow'))
            sql_query=f"update users set password = '{new_password}' where email = '{userData['email']}' AND contact='{userData['contact']}';"
            print(execute(sql_query))
            login()
        else:
            print(colored("\nWrong Contact",'red'))
    else:
        print(colored("\nWrong Email",'red'))

def login():
    print(colored('\n--------Login Page--------','blue'))
    print(colored('\nEnter Your Credentials ','magenta'))
    userData={'email':input(colored('\nEnter Your Email','yellow')),'password':input(colored('Enter Your Password','yellow'))}
    sql_query=f"select * from users where email='{userData['email']}'"
    print(execute(sql_query))
    result=cur.fetchone()
    if result is not None:
        user_id=result[0]
        if result[3]==userData['password']:
            option(user_id)
        else:
            print(colored("\nWrong Password",'red'))
            choice=int(input(colored('\nPress 1 to reset Password\nPress 2 to try Again','green')))
            if choice==1:
                    resetPassword()
            elif choice==2:
                    login()
            else:
                    print(colored("\nWrong Choice",'red'))
    else:
        print(colored("User Not Found \n Want to Register Yourself",'green'))
        choice=(input(colored('Press Y: to confirm N: to dismiss.','blue')))
        if choice.lower() == 'y':
            register()
        elif choice.lower() =='n':
            exit()
        else:
            print(colored("\nInvalid Input! Please Try again.",'red'))
            login()

def register():
    print(colored('\n-------Registration Page---------','blue'))
    userData={
        'name':input(colored('\nEnter Your Name','yellow')),
        'email':input(colored('Enter Your Email','yellow')),
        'password':input(colored('Enter Your Password','yellow')),
        'contact':input(colored('Enter Your Contact','yellow'))
        }
    sql_query=f"""
                    insert into users (name,email,password,contact)
                    values
                    ('{userData['name']}',
                    '{userData['email']}',
                    '{userData['password']}',
                    '{userData['contact']}');
                    """
    print(execute(sql_query))
    print(colored("\nRegistration Successful",'green'))
    login()