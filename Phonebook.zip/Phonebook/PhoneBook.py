import pbFunctions as pb 
from termcolor import colored
def homePage():
    print(colored('\n--------------Home Page--------------','blue'))
    print(colored("\n\n--------Welcome to the Phonebook--------",'grey'))
    choice=int(input(colored("\n\nPress 1 to Login\nPress 2 to Register\nPress 3 to Exit.",'green')))
    if choice == 1:
        pb.login()
    elif choice == 2:
        pb.register()
    elif choice == 3:
        exit()
    else:
        print(colored('\nChoose Valid Option','red'))

# MAIN        
while True:
    homePage()